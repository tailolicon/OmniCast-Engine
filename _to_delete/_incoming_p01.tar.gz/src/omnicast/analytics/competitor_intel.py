"""Learn from competitors' breakout videos — HOW winners name titles, design
thumbnails and structure scripts — and distill reusable playbooks per niche.

WHAT CHANGED (strategic review §4.1/§4.8, P0 items 1 and 3)

This module used to take `sort(views)[:12]`. That answers "what do high-view
videos look like", which is not "what made this video win":

  * absolute views favour BIG channels over the small channel that genuinely
    broke out, and OLD videos that merely accumulated views;
  * with no control group, every trait shared by the winners looks like a cause.
    Most of them are just the channel's house style — present in its flops too.
    That is textbook survivorship bias, and it was being written straight into
    the title/thumbnail/script generators.

So the input is now a COHORT from `analytics.cohort`: per-channel median
outliers (winners) each paired with an ordinary sibling video from the SAME
channel, close in publish date and similar in length (controls). Every prompt
below is a CONTRAST prompt — a pattern earns a place in a playbook only when it
separates the two groups. When no controls could be matched, the playbook is
still produced but is stamped UNCONTROLLED so downstream readers discount it
instead of trusting it equally.

Transcripts now come from `analytics.transcript`: full text (previously cut at
3,500 characters, i.e. the opening act stood in for the whole video) with an ASR
fallback for channels that publish no captions.

Pipeline:
  1. Scan competitor handles (reuse YouTubeScanner) → recent videos per channel.
  2. select_cohort → winners + matched controls.
  3. title_playbook  ← DeepSeek contrasts winner vs control titles.
  4. thumbnail_playbook ← Gemini/Claude vision contrasts winner vs control thumbs.
  5. script_playbook ← per-video digests of FULL transcripts, then a contrast
     synthesis across the two groups.
  6. Persist to vault.competitor_intel (keyed by niche) → fed into the title +
     thumbnail generators (clickbait.py).

Best-effort: needs youtube_api_key + competitor handles + (vision) GOOGLE_API_KEY.
Skips gracefully when missing.
"""

from __future__ import annotations

import asyncio
import atexit
import json
import time
import uuid
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone

import structlog

from omnicast.analytics.cohort import Cohort, select_cohort
from omnicast.analytics.transcript import Transcript, fetch_transcript

logger = structlog.get_logger()

# How many videos to pull per competitor channel before cohort selection. The
# channel median is only as honest as the sample it is computed over.
VIDEOS_PER_CHANNEL = 30
# Winners carried into the (expensive) transcript stage.
SCRIPT_SAMPLE_WINNERS = 4
# Per-video transcript digest budget. A 20-minute video is ~2 chunks; the cap
# stops one three-hour VOD from eating a whole learning run.
MAX_CHUNKS_PER_VIDEO = 4
TRANSCRIPT_CHUNK_CHARS = 12_000

# Thumbnail fetching: a per-socket timeout is not a deadline. A server dripping
# one byte every two seconds kept a single urlopen alive for 40s at timeout=15,
# and there are up to ten of them per run.
THUMB_TOTAL_DEADLINE_SECONDS = 45.0
THUMB_SOCKET_TIMEOUT = 10
THUMB_MAX_BYTES = 4 * 1024 * 1024
# Vision SDK ceilings. google-genai defaults to no timeout at all; anthropic
# defaults to 600s. Either one can pin a worker thread for the whole run.
VISION_TIMEOUT_SECONDS = 90

# Transcript and ASR run on their OWN small pool, not the default executor.
# asyncio's default is min(32, cpu+4) threads shared by every `to_thread` caller
# in the process; one 45-minute ASR job per worker starved unrelated 10ms calls
# for seconds at a time. Bounding it here also caps how many Whisper models can
# be resident at once.
RESEARCH_POOL_SIZE = 2
# A ThreadPoolExecutor queue is unbounded. Two threads plus an unbounded queue
# is not backpressure — it is an invisible hours-long backlog behind an HTTP
# request nobody can cancel. This caps how much work may be in flight at once
# and rejects the rest with a reason the caller can record.
MAX_RESEARCH_IN_FLIGHT = RESEARCH_POOL_SIZE * 4
_RESEARCH_EXECUTOR = ThreadPoolExecutor(
    max_workers=RESEARCH_POOL_SIZE, thread_name_prefix="omnicast-research")
_research_in_flight = 0


class ResearchPoolBusy(RuntimeError):
    """Raised instead of silently queueing behind a multi-hour backlog."""


@atexit.register
def _shutdown_research_pool() -> None:
    # Non-daemon worker threads make interpreter exit block on an unbounded
    # join: a SIGTERM to a worker mid-ASR hung for the whole ASR duration and
    # then got SIGKILLed.
    _RESEARCH_EXECUTOR.shutdown(wait=False, cancel_futures=True)


async def _in_research_pool(func, *args, **kwargs):
    """Run a long blocking research job off the loop AND off the shared pool."""
    global _research_in_flight
    if _research_in_flight >= MAX_RESEARCH_IN_FLIGHT:
        raise ResearchPoolBusy(
            f"{_research_in_flight} research jobs already in flight "
            f"(limit {MAX_RESEARCH_IN_FLIGHT}); refusing to queue another")
    loop = asyncio.get_running_loop()
    if kwargs:
        from functools import partial

        func = partial(func, **kwargs)
    _research_in_flight += 1
    try:
        return await loop.run_in_executor(_RESEARCH_EXECUTOR, func, *args)
    finally:
        _research_in_flight -= 1

# Prepended to any playbook learned without a control group. The reader — human
# or the writer agent — must be able to see that this is an observation, not a
# finding.
UNCONTROLLED_STAMP = (
    "[UNCONTROLLED — no matched control videos could be paired with these "
    "winners, so nothing below is verified to separate winners from the "
    "channel's ordinary output. Treat as a hypothesis, not a rule.]\n\n"
)

_CONTRAST_RULE = (
    "You are given two groups from the SAME channels: WINNERS (videos that beat "
    "their own channel's median by >=2x) and CONTROLS (ordinary videos from the "
    "same channel, published near the same time, similar length). Report ONLY "
    "what SEPARATES the groups. If a trait appears in both groups, it is that "
    "channel's house style, not a cause of winning — either omit it or label it "
    "explicitly as 'house style (not a differentiator)'. Do not invent a "
    "difference where the groups look alike; saying 'no reliable difference on "
    "X' is a valid and valuable answer."
)

_TITLE_SYS = (
    "You are a YouTube title strategist. " + _CONTRAST_RULE + "\n"
    "Distill a concise PLAYBOOK another creator can copy: the recurring formulas, "
    "power words, emotional triggers, number/bracket usage and ideal length that "
    "are present in WINNER titles and ABSENT (or much rarer) in CONTROL titles. "
    "End with 3 fill-in-the-blank title templates. Be specific and terse "
    "(<=200 words). Output plain text, no preamble."
)

_DIGEST_SYS = (
    "You are a YouTube retention analyst. You will receive the transcript of ONE "
    "video (possibly in sequential parts). Produce a compact, factual DIGEST — no "
    "praise, no advice:\n"
    "1. HOOK (first ~30s): what type (stat/question/pain/promise/story/cold-open) "
    "and what it promises.\n"
    "2. BEATS: the ordered segments with roughly where each starts (early/mid/late).\n"
    "3. OPEN LOOPS & RE-HOOKS: where a question is planted and where it is paid off.\n"
    "4. PACING: sentence rhythm, how often a new concrete idea/number lands.\n"
    "5. CTA: what is asked, and where.\n"
    "6. CLOSE: how it ends.\n"
    "<=160 words, plain text, no preamble."
)

_SCRIPT_SYS = (
    "You are a YouTube retention strategist. " + _CONTRAST_RULE + "\n"
    "You receive DIGESTS of full videos, each labelled WINNER or CONTROL. "
    "Reverse-engineer a SCRIPT PLAYBOOK covering: 1. HOOK formula, 2. STRUCTURE "
    "(beats and where open loops are planted/paid), 3. PACING, 4. RETENTION "
    "TACTICS, 5. TONE & LANGUAGE. For each, state the winner behaviour and the "
    "control behaviour it differs from. End with a copyable 5-beat outline "
    "template. Specific and terse (<=240 words). Plain text, no preamble."
)

_THUMB_SYS = (
    "You are a senior YouTube thumbnail art director reverse-engineering a CTR "
    "playbook. " + _CONTRAST_RULE + "\n"
    "The images are given in order and labelled for you in the final message. "
    "Compare across 5 layers: 1. FOCAL POINT, 2. LAYOUT & COMPOSITION (including "
    "keeping elements clear of the bottom-right timestamp), 3. COLOR & CONTRAST "
    "(does it pop in dark mode?), 4. CTR PSYCHOLOGY (which emotion, and how it "
    "pairs with the title to open a curiosity loop), 5. TYPOGRAPHY (word count, "
    "font class, outline, mobile legibility). End with 3 fill-in-the-blank "
    "thumbnail RECIPES that reproduce the WINNER side of each difference. "
    "Specific and terse (<=240 words). Plain text, no preamble."
)


# ── Cohort assembly ──────────────────────────────────────────────────────────

async def _fetch_competitor_videos(
    channel, api_key: str, per_channel: int = VIDEOS_PER_CHANNEL
) -> dict[str, list[dict]]:
    """Fetch recent videos for each competitor channel, KEPT GROUPED BY CHANNEL.

    The grouping is the point: a channel median cannot be computed once the
    videos have been poured into one flat list."""
    # Both the lazy imports (~540ms cold, mostly yt-dlp/httpx trees) and the
    # AsyncClient construction (~40ms every time, parsing a 240KB CA bundle) are
    # synchronous work that was running on the event loop.
    def _build_client():
        import httpx

        from omnicast.discovery.youtube_scanner import YouTubeScanner as _Scanner

        return httpx.AsyncClient(timeout=30), _Scanner

    http, _scanner_cls = await asyncio.to_thread(_build_client)
    # Resolved through the module so tests that patch
    # omnicast.discovery.youtube_scanner.YouTubeScanner still take effect.
    from omnicast.discovery import youtube_scanner as _ys

    scanner_cls = getattr(_ys, "YouTubeScanner", _scanner_cls)
    try:
        scanner = scanner_cls(config=channel, api_key=api_key, http_client=http)
        ids = list(getattr(channel, "competitor_channel_ids", []) or [])
        for handle in getattr(channel, "competitor_handles", []) or []:
            try:
                ids.append(await scanner._resolve_handle(handle))
            except Exception as exc:
                logger.warning("handle resolve failed", handle=handle, error=str(exc))

        by_channel: dict[str, list[dict]] = {}
        for cid in ids:
            try:
                pl = await scanner._get_channel_uploads_playlist_id(cid)
                vid_ids = await scanner._get_recent_video_ids(pl, max_results=per_channel)
                videos = await scanner._get_video_stats(vid_ids)
                if videos:
                    by_channel[cid] = videos
            except Exception as exc:
                logger.warning("competitor scan failed", channel=cid, error=str(exc))
        return by_channel
    finally:
        await http.aclose()


async def build_competitor_cohort(
    channel, api_key: str, *, max_winners: int = 12, per_channel: int = VIDEOS_PER_CHANNEL
) -> tuple[Cohort, dict[str, dict]]:
    """Winner + matched-control cohort for a channel's competitor set.

    Returns the cohort and a video_id → raw video dict lookup (thumbnails,
    duration, tags) for the stages that need more than the cohort row carries."""
    by_channel = await _fetch_competitor_videos(channel, api_key, per_channel=per_channel)
    cohort = select_cohort(by_channel, max_winners=max_winners)
    by_id = {v["video_id"]: v
             for videos in by_channel.values() for v in videos if v.get("video_id")}
    logger.info(
        "competitor cohort built",
        channels=len(by_channel),
        winners=len(cohort.winners),
        controls=len(cohort.controls),
        comparable=cohort.is_comparable,
    )
    return cohort, by_id


async def _all_competitor_videos(channel, api_key: str, top_n: int = 20) -> list[dict]:
    """Flat list of competitor videos, most-viewed first.

    NOT for learning — view-sorting is exactly the bias the cohort work removed.
    This exists for jobs that only need a pile of video IDs to mine (e.g. the
    BGM credit harvester reading video descriptions), where no causal claim is
    made about why those videos did well."""
    by_channel = await _fetch_competitor_videos(channel, api_key)
    videos = [v for group in by_channel.values() for v in group]
    videos.sort(key=lambda v: v.get("views", 0), reverse=True)
    return videos[:top_n]


def _stamp(text: str, cohort: Cohort) -> str:
    """Mark any playbook that had no control group to compare against."""
    if not text:
        return text
    return text if cohort.is_comparable else UNCONTROLLED_STAMP + text


def _labelled_titles(cohort: Cohort) -> str:
    lines = ["WINNERS (beat their own channel's median):"]
    for w in cohort.winners:
        lines.append(f"- [{w.outlier_ratio:.1f}x, {w.views_per_day:,.0f} views/day] {w.title}")
    if cohort.controls:
        lines.append("")
        lines.append("CONTROLS (ordinary videos, same channels, same period):")
        for c in cohort.controls:
            lines.append(f"- [{c.outlier_ratio:.1f}x] {c.title}")
    else:
        lines.append("")
        lines.append("CONTROLS: none could be matched — say so rather than guessing.")
    return "\n".join(lines)


# ── Title playbook ───────────────────────────────────────────────────────────

async def _learn_titles(llm, cohort: Cohort) -> str:
    if not cohort.winners:
        return ""
    try:
        resp = await llm.complete(
            system=_TITLE_SYS,
            messages=[{"role": "user", "content": _labelled_titles(cohort)}],
            max_tokens=650,
            temperature=0.4,
        )
        return _stamp((resp.content or "").strip(), cohort)
    except Exception as exc:
        logger.warning("title playbook failed", error=str(exc))
        return ""


# ── Thumbnail playbook ───────────────────────────────────────────────────────

def _fetch_thumbs(thumb_urls: list[str], limit: int = 8,
                  deadline: float | None = None) -> list[bytes]:
    """Download thumbnails under a WALL-CLOCK budget and a size cap.

    Two separate bugs lived here. `timeout=` on urlopen bounds each socket
    operation, not the transfer: a peer dribbling one byte every two seconds
    holds the connection open indefinitely without ever tripping it. And a
    deadline checked only at the top of the loop does not bound the request it
    is already inside — measured 80s spent against a 45s "budget". So the read
    is chunked and the clock is checked BETWEEN chunks.

    `deadline` is passed in so the two calls (winners, then controls) share one
    budget instead of getting 45 seconds each."""
    import urllib.request

    out: list[bytes] = []
    if deadline is None:
        deadline = time.monotonic() + THUMB_TOTAL_DEADLINE_SECONDS
    for u in [x for x in thumb_urls if x][:limit]:
        if time.monotonic() >= deadline:
            logger.warning("thumbnail budget exhausted", fetched=len(out),
                           requested=min(len(thumb_urls), limit))
            break
        try:
            req = urllib.request.Request(u, headers={"User-Agent": "Mozilla/5.0"})
            with urllib.request.urlopen(req, timeout=THUMB_SOCKET_TIMEOUT) as r:
                buffer = bytearray()
                while len(buffer) <= THUMB_MAX_BYTES:
                    if time.monotonic() >= deadline:
                        buffer = bytearray()   # abandon the partial download
                        break
                    chunk = r.read(64 * 1024)
                    if not chunk:
                        break
                    buffer.extend(chunk)
            if not buffer:
                continue
            if len(buffer) > THUMB_MAX_BYTES:
                logger.warning("thumbnail too large, skipped", url=u[:120])
                continue
            out.append(bytes(buffer))
        except Exception:
            continue
    return out


def _thumb_urls(cohort: Cohort, by_id: dict[str, dict], per_group: int = 5
                ) -> tuple[list[str], list[str]]:
    def urls(rows):
        out = []
        for row in rows[:per_group]:
            u = (by_id.get(row.video_id) or {}).get("thumbnail_url", "")
            if u:
                out.append(u)
        return out

    return urls(cohort.winners), urls(cohort.controls)


async def _learn_thumbnails_async(cohort: Cohort, by_id: dict[str, dict], **kwargs) -> str:
    """Off-loop wrapper around `_learn_thumbnails`.

    That function downloads up to 10 thumbnails over urllib at a 15s timeout
    each and then calls the Gemini/Anthropic SDKs synchronously — worst case a
    couple of minutes with the event loop held. It was being awaited-adjacent
    (called directly) from inside an async handler."""
    return await _in_research_pool(_learn_thumbnails, cohort, by_id, **kwargs)


def _learn_thumbnails(cohort: Cohort, by_id: dict[str, dict], google_key: str = "",
                      claude_key: str = "", claude_model: str = "claude-sonnet-5") -> str:
    """Vision contrast of winner vs control thumbnails → CTR design playbook.
    Prefers Gemini 2.5-flash (cheap), falls back to Claude vision. '' if no key/images.

    BLOCKING (network + sync SDK) — coroutines must use
    `_learn_thumbnails_async`."""
    if not (claude_key or google_key):
        return ""
    winner_urls, control_urls = _thumb_urls(cohort, by_id)
    # ONE budget for the whole stage, not one per group.
    deadline = time.monotonic() + THUMB_TOTAL_DEADLINE_SECONDS
    winner_imgs = _fetch_thumbs(winner_urls, deadline=deadline)
    control_imgs = _fetch_thumbs(control_urls, deadline=deadline)
    if not winner_imgs:
        return ""

    imgs = winner_imgs + control_imgs
    if control_imgs:
        legend = (
            f"The first {len(winner_imgs)} image(s) are WINNER thumbnails; the "
            f"remaining {len(control_imgs)} are CONTROL thumbnails from the same "
            "channels. Analyse the contrast per your brief."
        )
    else:
        legend = (
            f"All {len(winner_imgs)} image(s) are WINNER thumbnails. No controls "
            "were available, so state plainly that differences from ordinary "
            "videos could not be verified, then describe what the winners share."
        )

    # 1) Gemini 2.5-flash (cheap, default).
    if google_key:
        try:
            from google import genai
            from google.genai import types

            parts = [types.Part.from_bytes(data=b, mime_type="image/jpeg") for b in imgs]
            client = genai.Client(
                api_key=google_key,
                http_options=types.HttpOptions(timeout=VISION_TIMEOUT_SECONDS * 1000),
            )
            resp = client.models.generate_content(
                model="gemini-2.5-flash", contents=[*parts, _THUMB_SYS, legend])
            txt = (resp.candidates[0].content.parts[0].text or "").strip()
            if txt:
                logger.info("thumbnail playbook via Gemini",
                            winners=len(winner_imgs), controls=len(control_imgs))
                return _stamp(txt, cohort)
        except Exception as exc:
            logger.warning("gemini thumbnail analysis failed", error=str(exc))

    # 2) Claude vision fallback (when no Google key).
    if claude_key:
        try:
            import base64

            import anthropic

            blocks = [{"type": "image", "source": {
                "type": "base64", "media_type": "image/jpeg",
                "data": base64.b64encode(b).decode()}} for b in imgs]
            blocks.append({"type": "text", "text": legend})
            client = anthropic.Anthropic(api_key=claude_key,
                                         timeout=VISION_TIMEOUT_SECONDS)
            msg = client.messages.create(
                model=claude_model, max_tokens=900, system=_THUMB_SYS,
                messages=[{"role": "user", "content": blocks}])
            txt = "".join(b.text for b in msg.content
                          if getattr(b, "type", "") == "text").strip()
            if txt:
                logger.info("thumbnail playbook via Claude",
                            winners=len(winner_imgs), controls=len(control_imgs))
                return _stamp(txt, cohort)
        except Exception as exc:
            logger.warning("claude thumbnail analysis failed", error=str(exc))
    return ""


# ── Script playbook ──────────────────────────────────────────────────────────

def _fetch_transcript(video_id: str, duration_minutes: float = 0.0) -> Transcript:
    """Full transcript for one competitor video (captions, else ASR).

    BLOCKING: HTTP for captions, and on the ASR path a yt-dlp download plus
    minutes of CPU-bound Whisper. Never call this directly from a coroutine —
    use `_fetch_transcript_async`. Kept as a thin seam so tests can substitute
    a fixed transcript."""
    return fetch_transcript(video_id, duration_minutes=duration_minutes)


async def _fetch_transcript_async(video_id: str, duration_minutes: float = 0.0) -> Transcript:
    """Off-loop wrapper around `_fetch_transcript`.

    `learn_for_channel` is awaited from inside the FastAPI app. A single
    caption-less 40-minute video on the ASR path would otherwise freeze every
    other request on that worker for the duration of the transcription.
    Resolved through the module global so tests can still patch
    `_fetch_transcript`."""
    return await _in_research_pool(_fetch_transcript, video_id, duration_minutes)


async def _digest_video(llm, label: str, title: str, transcript: Transcript) -> str:
    """Compress ONE full transcript into a structural digest.

    Map step of a map-reduce: the whole video reaches the model in sequential
    chunks, and only the digest — not the raw 20k characters — is carried into
    the cross-video synthesis. This is what replaced `transcript[:3500]`."""
    chunks = transcript.chunks(max_chars=TRANSCRIPT_CHUNK_CHARS)
    if not chunks:
        return ""
    dropped = 0
    if len(chunks) > MAX_CHUNKS_PER_VIDEO:
        dropped = len(chunks) - MAX_CHUNKS_PER_VIDEO
        chunks = chunks[:MAX_CHUNKS_PER_VIDEO]
    body = "\n\n".join(
        f"--- part {i + 1} of {len(chunks)} ---\n{c}" for i, c in enumerate(chunks)
    )
    user = f"Video: {title or '(untitled)'}\nSource: {transcript.describe()}\n\n{body}"
    if dropped:
        user += (
            f"\n\n[NOTE: {dropped} later part(s) of this transcript were not "
            "included — say nothing about how the video ends.]"
        )
    try:
        resp = await llm.complete(
            system=_DIGEST_SYS,
            messages=[{"role": "user", "content": user}],
            max_tokens=400,
            temperature=0.3,
        )
        digest = (resp.content or "").strip()
    except Exception as exc:
        logger.warning("transcript digest failed", video_id=transcript.video_id, error=str(exc))
        return ""
    if not digest:
        return ""
    return f"### {label}: {title or '(untitled)'}\n{digest}"


async def _learn_scripts(llm, cohort: Cohort, by_id: dict[str, dict],
                         top_n: int = SCRIPT_SAMPLE_WINNERS) -> tuple[str, list[str]]:
    """Distill a script playbook by contrasting winner and control structure.

    Returns (playbook, notes) — notes record every video that dropped out of the
    sample and why, so a thin sample is never mistaken for a strong signal."""
    notes: list[str] = []
    winners = cohort.winners[:top_n]
    if not winners:
        return "", notes

    wanted_ids = {w.video_id for w in winners}
    controls = [c for c in cohort.controls if c.matched_to in wanted_ids]

    digests: list[str] = []
    for row, label in [(w, "WINNER") for w in winners] + [(c, "CONTROL") for c in controls]:
        duration = float((by_id.get(row.video_id) or {}).get("duration_minutes", 0) or 0)
        try:
            transcript = await _fetch_transcript_async(
                row.video_id, duration_minutes=duration)
        except ResearchPoolBusy as exc:
            notes.append(f"{label} {row.video_id}: skipped — {exc}")
            continue
        if not transcript.ok:
            notes.append(f"{label} {row.video_id}: no transcript ({transcript.note})")
            continue
        digest = await _digest_video(llm, label, row.title, transcript)
        if digest:
            digests.append(digest)
        else:
            notes.append(f"{label} {row.video_id}: digest failed")

    if not any(d.startswith("### WINNER") for d in digests):
        notes.append("script playbook skipped: no winner transcript was usable")
        return "", notes

    control_digests = sum(1 for d in digests if d.startswith("### CONTROL"))
    if not control_digests:
        notes.append("script playbook is winner-only: no control transcript was usable")

    user = "Video digests:\n\n" + "\n\n".join(digests)
    try:
        resp = await llm.complete(
            system=_SCRIPT_SYS,
            messages=[{"role": "user", "content": user}],
            max_tokens=800,
            temperature=0.4,
        )
        playbook = (resp.content or "").strip()
    except Exception as exc:
        logger.warning("script playbook failed", error=str(exc))
        return "", notes

    if playbook and not control_digests:
        playbook = UNCONTROLLED_STAMP + playbook
    return _stamp(playbook, cohort), notes


# ── Orchestration ────────────────────────────────────────────────────────────

ARTIFACT_FIELDS = ("title_playbook", "thumbnail_playbook", "script_playbook")


def _merge_run(previous, produced: dict[str, str], run_provenance: dict
               ) -> tuple[dict[str, str], dict]:
    """Combine this run's artifacts with whatever must be carried forward.

    The rule: an artifact and its provenance move TOGETHER. A run that failed to
    produce a script playbook may keep the previous one — but it keeps the
    previous one's run id, timestamp and comparability too, so the gate judges
    the text that actually exists rather than the cohort that happens to be
    newest. The old SQL kept the artifact and replaced the metadata, which is
    how a playbook learned with no control group could later read as verified.
    """
    previous_meta: dict = {}
    if previous is not None:
        try:
            previous_meta = json.loads(getattr(previous, "cohort_meta", "") or "{}")
            if not isinstance(previous_meta, dict):
                previous_meta = {}
        except Exception:
            previous_meta = {}
    previous_artifacts = previous_meta.get("artifacts") or {}

    final: dict[str, str] = {}
    artifacts: dict[str, dict] = {}
    carried: list[str] = []

    for field_name in ARTIFACT_FIELDS:
        fresh = (produced.get(field_name) or "").strip()
        if fresh:
            final[field_name] = fresh
            artifacts[field_name] = dict(run_provenance)
            continue
        inherited = (getattr(previous, field_name, "") or "").strip() if previous else ""
        if inherited:
            final[field_name] = inherited
            # No per-artifact record on the older row (pre-migration): fall back
            # to that row's run-level provenance, never to this run's.
            inherited_meta = dict(previous_artifacts.get(field_name) or {}) or {
                k: v for k, v in previous_meta.items()
                if k in {"research_run_id", "generated_at", "is_comparable",
                         "winner_count", "control_count"}
            }
            if not inherited_meta:
                # Nothing known about where this text came from. Say exactly
                # that. An empty dict would let the gate fall through to the
                # row's metadata — i.e. to THIS run's credentials — which is the
                # laundering this whole function exists to stop.
                inherited_meta = {"research_run_id": "", "generated_at": "",
                                  "is_comparable": None, "provenance": "unknown"}
            artifacts[field_name] = inherited_meta
            carried.append(field_name)
        else:
            final[field_name] = ""

    return final, {"artifacts": artifacts, "carried_forward": carried}


async def learn_for_channel(channel, niche_key: str) -> dict | None:
    """Distill + persist competitor title/thumbnail/script playbooks for a niche.
    Returns a summary dict, or None if nothing learnable."""
    from omnicast.capabilities.llm_factory import create_llm
    from omnicast.config.settings import get_settings
    from omnicast.vault import db as vault_db
    from omnicast.vault.models import CompetitorIntel

    s = get_settings()
    api_key = s.youtube_api_key
    if not api_key:
        return None

    cohort, by_id = await build_competitor_cohort(channel, api_key)
    if not cohort.winners:
        logger.info("no competitor winners cleared the outlier threshold",
                    niche=niche_key, notes=cohort.notes[:5])
        return None

    titles = [w.title for w in cohort.winners if w.title]

    # One research run = one id. Everything this run produces is stamped with it,
    # so a downstream reader can always answer "which cohort produced this text".
    run_id = uuid.uuid4().hex[:12]
    generated_at = datetime.now(timezone.utc).isoformat()

    # create_llm is synchronous and heavier than it looks: it opens several
    # sqlite connections (capability registry, key pool, budget guard) and can
    # shell out to nvidia-smi while probing local candidates. Measured ~190ms of
    # event-loop stall cold, on a coroutine served by the API worker.
    llm = await asyncio.to_thread(
        create_llm, default_provider="deepseek", model=s.deepseek_flash_model)
    title_pb = await _learn_titles(llm, cohort)
    try:
        thumb_pb = await _learn_thumbnails_async(
            cohort, by_id, google_key=s.google_api_key, claude_key=s.claude_api_key,
            claude_model=s.claude_model)
    except ResearchPoolBusy as exc:
        logger.warning("thumbnail playbook skipped", reason=str(exc))
        thumb_pb = ""
    script_pb, script_notes = await _learn_scripts(llm, cohort, by_id)
    if not title_pb and not thumb_pb and not script_pb:
        logger.warning("competitor intel run produced nothing", niche=niche_key,
                       research_run_id=run_id, notes=(cohort.notes + script_notes)[:5])
        return None

    run_provenance = {
        "research_run_id": run_id,
        "generated_at": generated_at,
        "is_comparable": cohort.is_comparable,
        "winner_count": len(cohort.winners),
        "control_count": len(cohort.controls),
    }

    from pathlib import Path

    VAULT_DB = Path(__file__).resolve().parents[3] / "output" / "vault.db"

    def _persist() -> dict:
        """Read-merge-write in one place, off the event loop.

        sqlite is blocking, and the merge has to see the row it is replacing."""
        vault_db.init_db(VAULT_DB)
        previous = vault_db.get_competitor_intel(niche_key, VAULT_DB)
        artifacts, merge_meta = _merge_run(
            previous,
            {"title_playbook": title_pb, "thumbnail_playbook": thumb_pb,
             "script_playbook": script_pb},
            run_provenance,
        )
        meta = {
            **run_provenance,
            "selection": cohort.as_packet()["selection"],
            "notes": cohort.notes + script_notes,
            **merge_meta,
        }
        vault_db.upsert_competitor_intel(CompetitorIntel(
            niche=niche_key,
            title_playbook=artifacts["title_playbook"],
            thumbnail_playbook=artifacts["thumbnail_playbook"],
            script_playbook=artifacts["script_playbook"],
            sample_titles=titles[:15],
            sample_count=len(cohort.winners),
            cohort_meta=json.dumps(meta, ensure_ascii=False),
            updated_at=generated_at,
        ), VAULT_DB)
        return meta

    meta = await asyncio.to_thread(_persist)
    try:
        from omnicast.agents.writer import invalidate_competitor_intel_cache

        # The writer caches under the lowercased scope key.
        invalidate_competitor_intel_cache(str(niche_key).lower())
    except Exception as exc:  # never let cache housekeeping fail a run
        logger.warning("intel cache invalidation failed", error=str(exc))

    logger.info("competitor intel learned", niche=niche_key, research_run_id=run_id,
                winners=len(cohort.winners), controls=len(cohort.controls),
                comparable=cohort.is_comparable, has_title=bool(title_pb),
                has_thumb=bool(thumb_pb), has_script=bool(script_pb),
                carried_forward=meta.get("carried_forward", []))
    return {
        "niche": niche_key,
        "research_run_id": run_id,
        "samples": len(cohort.winners),
        "winners": len(cohort.winners),
        "controls": len(cohort.controls),
        "is_comparable": cohort.is_comparable,
        "title_playbook": bool(title_pb),
        "thumbnail_playbook": bool(thumb_pb),
        "script_playbook": bool(script_pb),
        "carried_forward": meta.get("carried_forward", []),
        "notes": meta["notes"][:10],
    }
