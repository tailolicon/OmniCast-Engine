"""YouTubePlatform.fetch_comments — real commentThreads read (P0 item 2).

The bug: `fetch_comments` was `return []`. An audience-feedback consumer could
not distinguish "this video has no comments" from "this was never implemented",
so a stub read as a finding. These tests pin real paging, reply flattening, and
— most importantly — that an empty result now carries its reason."""

from __future__ import annotations

import pytest

from omnicast.platforms.models import PlatformId
from omnicast.platforms.youtube import YouTubePlatform


class FakeRequest:
    def __init__(self, payload):
        self._payload = payload

    def execute(self):
        return self._payload


class FakeThreads:
    """Stands in for service.commentThreads(); records the params it was given."""

    def __init__(self, pages, error=None):
        self.pages = pages
        self.error = error
        self.calls: list[dict] = []

    def list(self, **kwargs):
        self.calls.append(kwargs)
        if self.error:
            raise self.error
        return FakeRequest(self.pages[len(self.calls) - 1])


class FakeService:
    def __init__(self, threads):
        self._threads = threads

    def commentThreads(self):
        return self._threads


def _thread(cid, text, replies=0, reply_texts=()):
    item = {
        "id": f"thread_{cid}",
        "snippet": {
            "videoId": "vid1",
            "totalReplyCount": replies,
            "topLevelComment": {
                "id": cid,
                "snippet": {
                    "authorDisplayName": f"user_{cid}",
                    "authorChannelId": {"value": f"UC_{cid}"},
                    "textOriginal": text,
                    "likeCount": 7,
                    "publishedAt": "2026-07-01T00:00:00Z",
                    "updatedAt": "2026-07-01T00:00:00Z",
                },
            },
        },
    }
    if reply_texts:
        item["replies"] = {"comments": [
            {"id": f"{cid}_r{i}", "snippet": {
                "videoId": "vid1", "authorDisplayName": "replier",
                "authorChannelId": {"value": "UC_r"}, "textOriginal": t,
                "likeCount": 1, "publishedAt": "2026-07-02T00:00:00Z",
                "parentId": cid}}
            for i, t in enumerate(reply_texts)
        ]}
    return item


def _platform(monkeypatch, service=None, error=None, pages=None, dry_run=False):
    plat = YouTubePlatform(uploader=object())
    threads = FakeThreads(pages or [], error=error)
    fake = service or FakeService(threads)

    async def _build(self=None):
        if error and isinstance(error, RuntimeError):
            raise error
        return fake

    monkeypatch.setattr(YouTubePlatform, "_build_comment_service",
                        lambda self: _build())

    class _Settings:
        is_dry_run = dry_run
        youtube_api_key = "k"

    import omnicast.config.settings as settings_mod

    monkeypatch.setattr(settings_mod, "get_settings", lambda: _Settings())
    return plat, threads


async def test_returns_real_comments_with_replies_flattened(monkeypatch):
    pages = [{"items": [_thread("c1", "great video", replies=1, reply_texts=["thanks"])]}]
    plat, threads = _platform(monkeypatch, pages=pages)
    out = await plat.fetch_comments("vid1", "acct")
    assert [c["text"] for c in out] == ["great video", "thanks"]
    top, reply = out
    assert top["is_reply"] is False and top["reply_count"] == 1
    assert reply["is_reply"] is True and reply["parent_id"] == "c1"
    assert top["author_channel_id"] == "UC_c1"
    assert top["like_count"] == 7
    assert plat._last_comments_error == ""


async def test_pages_until_the_cap_then_stops(monkeypatch):
    pages = [
        {"items": [_thread(f"a{i}", f"t{i}") for i in range(2)], "nextPageToken": "p2"},
        {"items": [_thread(f"b{i}", f"u{i}") for i in range(2)]},
    ]
    plat, threads = _platform(monkeypatch, pages=pages)
    out = await plat.fetch_comments("vid1", "acct", max_comments=4)
    assert len(out) == 4
    assert len(threads.calls) == 2
    assert threads.calls[1]["pageToken"] == "p2"


async def test_cap_is_respected_even_mid_page(monkeypatch):
    pages = [{"items": [_thread(f"a{i}", f"t{i}") for i in range(5)]}]
    plat, _ = _platform(monkeypatch, pages=pages)
    out = await plat.fetch_comments("vid1", "acct", max_comments=3)
    assert len(out) == 3


async def test_disabled_comments_report_a_reason_not_a_bare_empty_list(monkeypatch):
    """The whole point of the fix: emptiness must be explainable."""

    class ApiError(Exception):
        pass

    plat, _ = _platform(monkeypatch, pages=[], error=ApiError("commentsDisabled for video"))
    out = await plat.fetch_comments("vid1", "acct")
    assert out == []
    assert plat._last_comments_error == "comments_disabled"


async def test_quota_exhaustion_is_distinguishable_from_disabled(monkeypatch):
    class ApiError(Exception):
        pass

    plat, _ = _platform(monkeypatch, pages=[], error=ApiError("quotaExceeded"))
    assert await plat.fetch_comments("vid1", "acct") == []
    assert plat._last_comments_error == "quota_exceeded"


async def test_dry_run_says_dry_run(monkeypatch):
    plat, _ = _platform(monkeypatch, pages=[{"items": []}], dry_run=True)
    assert await plat.fetch_comments("vid1", "acct") == []
    assert plat._last_comments_error == "dry_run"


async def test_missing_post_id_is_rejected_before_any_api_call(monkeypatch):
    plat, threads = _platform(monkeypatch, pages=[{"items": []}])
    assert await plat.fetch_comments("", "acct") == []
    assert plat._last_comments_error == "no post_id"
    assert threads.calls == []


async def test_request_asks_for_replies_and_plain_text(monkeypatch):
    plat, threads = _platform(monkeypatch, pages=[{"items": []}])
    await plat.fetch_comments("vid1", "acct")
    params = threads.calls[0]
    assert "replies" in params["part"]
    assert params["textFormat"] == "plainText"
    assert params["videoId"] == "vid1"


def test_platform_id_unchanged():
    assert YouTubePlatform.id == PlatformId.YOUTUBE.value


@pytest.mark.parametrize("blob,expected", [
    ("commentsDisabled", "comments_disabled"),
    ("rateLimitExceeded", "quota_exceeded"),
    ("videoNotFound", "video_not_found"),
])
def test_error_reasons_are_mapped(blob, expected):
    from omnicast.platforms.youtube import _comment_error_reason

    assert _comment_error_reason(Exception(blob)) == expected
