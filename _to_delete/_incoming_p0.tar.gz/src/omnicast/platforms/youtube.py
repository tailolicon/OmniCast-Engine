"""YouTube platform adapter around the existing upload pipeline."""

from __future__ import annotations

import asyncio

import structlog

from omnicast.platforms.analytics_store import PlatformAnalyticsStore
from omnicast.platforms.models import (
    AuthState,
    FormatSpec,
    PlatformId,
    PlatformStatus,
    PolicyIssue,
    PolicySeverity,
    PostStats,
    PublishMetadata,
    PublishRequest,
    PublishResult,
    QuotaInfo,
)
from omnicast.upload.compliance import ComplianceChecker
from omnicast.upload.models import UploadMetadata, UploadRequest, UploadStatus
from omnicast.upload.oauth import OAuth2Manager
from omnicast.upload.youtube_api import YouTubeUploader

logger = structlog.get_logger()

# commentThreads.list / comments.list cost 1 quota unit per call, and each call
# returns up to 100 items. The cap below therefore bounds both quota and the
# time a feedback sweep can take on a video with 40k comments.
MAX_COMMENTS_DEFAULT = 200
COMMENTS_PAGE_SIZE = 100


def _to_upload_metadata(metadata: PublishMetadata) -> UploadMetadata:
    return UploadMetadata(
        title=metadata.title,
        description=metadata.description,
        tags=metadata.tags,
        language=metadata.language,
        ai_disclosure=metadata.ai_disclosure,
        privacy_status=metadata.privacy_status,
        publish_at=metadata.publish_at,
        made_for_kids=metadata.made_for_kids,
    )


def _to_upload_request(request: PublishRequest) -> UploadRequest:
    return UploadRequest(
        video_id=request.video_id,
        channel_id=request.account_id,
        video_path=request.video_path,
        thumbnail_paths=request.thumbnail_paths,
        metadata=_to_upload_metadata(request.metadata),
    )


class YouTubePlatform:
    """Official YouTube Data API v3 adapter."""

    id = PlatformId.YOUTUBE.value
    format_spec = FormatSpec(
        variant="youtube_16x9",
        aspect_ratio="16:9",
        width=1920,
        height=1080,
        caption_max_length=5000,
        supports_scheduling=True,
        supports_thumbnail=True,
    )

    def __init__(
        self,
        uploader: YouTubeUploader,
        oauth: OAuth2Manager | None = None,
        compliance: ComplianceChecker | None = None,
        analytics_store: PlatformAnalyticsStore | None = None,
    ) -> None:
        self.uploader = uploader
        self.oauth = oauth
        self.compliance = compliance or ComplianceChecker()
        self.analytics_store = analytics_store
        # Why the last comment fetch came back empty ("" = it did not fail).
        self._last_comments_error = ""
        self._comment_account_id = ""

    async def authenticate(self, account_id: str) -> AuthState:
        if not self.oauth:
            return AuthState(
                platform_id=PlatformId.YOUTUBE,
                account_id=account_id,
                authenticated=False,
                error="OAuth2Manager not configured",
            )
        health = await self.oauth.check_health(account_id)
        return AuthState(
            platform_id=PlatformId.YOUTUBE,
            account_id=account_id,
            authenticated=health.error is None,
            scopes=health.scopes,
            expires_at=health.expires_at,
            error=health.error,
        )

    async def quota(self, account_id: str) -> QuotaInfo:
        return QuotaInfo(
            platform_id=PlatformId.YOUTUBE,
            account_id=account_id,
            remaining=None,
            unit="quota_units",
            details={"upload_cost_with_thumbnail": self.uploader.estimate_quota_cost(True)},
        )

    async def validate(self, request: PublishRequest) -> list[PolicyIssue]:
        result = self.compliance.check(_to_upload_request(request))
        return [
            PolicyIssue(
                code="youtube_compliance",
                message=violation,
                severity=PolicySeverity.BLOCKING,
            )
            for violation in result.violations
        ]

    async def publish(self, request: PublishRequest) -> PublishResult:
        issues = await self.validate(request)
        blocking = [issue for issue in issues if issue.severity == PolicySeverity.BLOCKING]
        if blocking:
            return PublishResult(
                platform_id=PlatformId.YOUTUBE,
                account_id=request.account_id,
                status=PlatformStatus.FAILED,
                error="; ".join(issue.message for issue in blocking),
            )

        result = await self.uploader.upload(_to_upload_request(request))
        status = (
            PlatformStatus.FAILED
            if result.status == UploadStatus.FAILED
            else PlatformStatus.PUBLISHED
        )
        return PublishResult(
            platform_id=PlatformId.YOUTUBE,
            account_id=request.account_id,
            post_id=result.youtube_video_id,
            status=status,
            url=result.url,
            published_at=result.published_at,
            thumbnail_set=result.thumbnail_set,
            error=result.error,
        )

    async def fetch_analytics(self, post_id: str, account_id: str) -> PostStats:
        if self.analytics_store:
            stats = self.analytics_store.latest(self.id, post_id)
            if stats:
                return stats
        return PostStats(
            platform_id=PlatformId.YOUTUBE,
            account_id=account_id,
            post_id=post_id,
            raw={"source": "youtube_platform_adapter", "ingested": False},
        )

    # ── Comments ─────────────────────────────────────────────────────────────
    #
    # This returned `[]` unconditionally, which is worse than not existing: an
    # audience-feedback loop reading it could not tell "this video has no
    # comments" from "nobody implemented this", so a silent empty list looked
    # like a real signal. Now it either returns real comments or says why it
    # could not (`_last_comments_error`), and callers that want the reason can
    # read it instead of inferring it from emptiness.

    async def _build_comment_service(self):
        """YouTube Data API client for reading comments.

        OAuth credentials when the adapter has them (also lets us read comments
        on unlisted/private videos we own); otherwise a plain API key, which is
        enough for public comment threads."""
        if self.oauth:
            credentials = await self.oauth.get_credentials(self._comment_account_id or "")
            return self.uploader._build_service(credentials)

        from omnicast.config.settings import get_settings

        api_key = getattr(get_settings(), "youtube_api_key", "")
        if not api_key:
            raise RuntimeError("no OAuth manager and no youtube_api_key configured")
        from googleapiclient.discovery import build

        return build("youtube", "v3", developerKey=api_key, cache_discovery=False)

    @staticmethod
    def _normalize_thread(item: dict) -> list[dict]:
        """Flatten one commentThread into top-level comment + replies."""
        out: list[dict] = []
        thread_id = item.get("id", "")
        snippet = item.get("snippet", {}) or {}
        top = (snippet.get("topLevelComment") or {}).get("snippet", {}) or {}
        if top:
            out.append({
                "comment_id": (snippet.get("topLevelComment") or {}).get("id", thread_id),
                "thread_id": thread_id,
                "video_id": snippet.get("videoId", ""),
                "author": top.get("authorDisplayName", ""),
                "author_channel_id": (top.get("authorChannelId") or {}).get("value", ""),
                "text": top.get("textOriginal") or top.get("textDisplay", "") or "",
                "like_count": int(top.get("likeCount", 0) or 0),
                "published_at": top.get("publishedAt", ""),
                "updated_at": top.get("updatedAt", ""),
                "reply_count": int(snippet.get("totalReplyCount", 0) or 0),
                "is_reply": False,
                "parent_id": "",
            })
        for reply in (item.get("replies", {}) or {}).get("comments", []) or []:
            r = reply.get("snippet", {}) or {}
            out.append({
                "comment_id": reply.get("id", ""),
                "thread_id": thread_id,
                "video_id": r.get("videoId", ""),
                "author": r.get("authorDisplayName", ""),
                "author_channel_id": (r.get("authorChannelId") or {}).get("value", ""),
                "text": r.get("textOriginal") or r.get("textDisplay", "") or "",
                "like_count": int(r.get("likeCount", 0) or 0),
                "published_at": r.get("publishedAt", ""),
                "updated_at": r.get("updatedAt", ""),
                "reply_count": 0,
                "is_reply": True,
                "parent_id": r.get("parentId", ""),
            })
        return out

    def _list_comment_threads(self, service, post_id: str, max_comments: int,
                              order: str) -> list[dict]:
        """Blocking paging loop — run via asyncio.to_thread by the caller."""
        collected: list[dict] = []
        page_token = ""
        while len(collected) < max_comments:
            request = service.commentThreads().list(
                part="snippet,replies",
                videoId=post_id,
                maxResults=min(COMMENTS_PAGE_SIZE, max_comments - len(collected)),
                order=order,
                textFormat="plainText",
                pageToken=page_token or None,
            )
            response = request.execute() or {}
            for item in response.get("items", []):
                collected.extend(self._normalize_thread(item))
            page_token = response.get("nextPageToken", "")
            if not page_token:
                break
        return collected[:max_comments]

    async def fetch_comments(
        self,
        post_id: str,
        account_id: str,
        *,
        max_comments: int = MAX_COMMENTS_DEFAULT,
        order: str = "relevance",
    ) -> list[dict]:
        """Real commentThreads.list read, paged and normalized.

        Returns top-level comments and their replies as flat dicts. An empty
        list now means "nothing came back", and `_last_comments_error` carries
        the reason (comments disabled, quota exhausted, video not found, no
        credentials) whenever that emptiness was caused by a failure."""
        self._last_comments_error = ""
        if not post_id:
            self._last_comments_error = "no post_id"
            return []

        from omnicast.config.settings import get_settings

        if getattr(get_settings(), "is_dry_run", False):
            self._last_comments_error = "dry_run"
            return []

        self._comment_account_id = account_id
        try:
            service = await self._build_comment_service()
            comments = await asyncio.to_thread(
                self._list_comment_threads, service, post_id, max(1, max_comments), order
            )
        except Exception as exc:
            reason = _comment_error_reason(exc)
            self._last_comments_error = reason
            # Comments being switched off is a normal channel setting, not an
            # incident; a quota wall is.
            log = logger.info if reason == "comments_disabled" else logger.warning
            log("comment fetch returned nothing", post_id=post_id, reason=reason,
                error=str(exc)[:200])
            return []

        logger.info("comments fetched", post_id=post_id, count=len(comments))
        return comments


def _comment_error_reason(exc: Exception) -> str:
    """Map a Google API error onto a short, checkable reason string."""
    detail = str(exc)
    status = getattr(getattr(exc, "resp", None), "status", None)
    if "commentsDisabled" in detail or "disabled comments" in detail:
        return "comments_disabled"
    if "quotaExceeded" in detail or "rateLimitExceeded" in detail or status == 429:
        return "quota_exceeded"
    if "videoNotFound" in detail or status == 404:
        return "video_not_found"
    if status == 403:
        return "forbidden"
    if "youtube_api_key" in detail or "OAuth" in detail:
        return "no_credentials"
    return type(exc).__name__
