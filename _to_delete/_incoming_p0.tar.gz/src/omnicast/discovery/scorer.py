"""Topic scoring engine.

Scores raw topics 0-100 across 5 dimensions:
- Trend Momentum: 0-30 (is anyone asking for this? — growth/outlier signal)
- Gap Score:      0-25 (is the space already served? — saturation signal)
- RPM Potential:  0-20 (market RPM floor)
- Novelty vs KB:  0-10 (ChromaDB similarity check, decay-aware)
- Stack Fit:      0-15 (can WE actually make this well?)

WHY THE DIMENSIONS MOVED (strategic review §4, P0 item 4)

`outlier_ratio` used to drive BOTH trend_momentum (`min(ratio*3, 30)`) and
gap_score (tiered 20/28/35). One measurement was therefore counted twice, and a
single YouTube outlier could contribute 65 of the 100 available points on its
own — enough to clear the 70 auto-approve line with nothing else agreeing. Worse,
the two dimensions are supposed to answer OPPOSITE questions:

    trend momentum → "is there demand?"     (high ratio = yes)
    gap score      → "is it already served?" (high ratio says nothing about this;
                                              if anything a monster outlier means
                                              a big channel just covered it)

So gap_score no longer reads outlier_ratio at all. It reads saturation signals:
how big the incumbent is, how many competitor videos already cover the topic,
and whether the audience engaged harder than that channel's norm (unmet demand).
Absent data stays NEUTRAL — "we don't know how crowded this is" must not score
the same as "we checked and it's empty".

The 15 points freed from gap became STACK FIT. Demand for something we cannot
produce well is not opportunity: a topic needing live footage, a face on camera,
or a runtime our pipeline does not do is a topic we will ship badly. Nothing in
the old score could say so.

Thresholds (recalibrated — the old ones assumed the double-count):
  >= 70: auto_approved
  50-69: needs_review (Telegram alert)
  < 50:  discard
A YouTube outlier now needs at least two dimensions agreeing to auto-approve.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import structlog

from omnicast.discovery.models import ScoredTopic, TopicRawData
from omnicast.models.enums import Market, Niche, TopicSource

logger = structlog.get_logger()

# RPM floor by market (USD)
MARKET_RPM: dict[Market, float] = {
    Market.US: 15.0,
    Market.UK: 12.0,
    Market.AU: 10.0,
    Market.CA: 10.0,
    Market.JP: 8.0,
    Market.KR: 7.0,
}

GAP_MAX = 25.0
STACK_FIT_MAX = 15.0
# Neutral = "unknown", deliberately mid-scale. Used when no stack profile is
# configured, so an unconfigured system neither rewards nor punishes fit.
STACK_FIT_NEUTRAL = 7.5
# Baseline for a YouTube outlier before saturation evidence moves it.
YOUTUBE_GAP_BASE = 12.0

# Saturation-only gap defaults per source (0-25). Ordering preserved from the
# original 0-40 scale: podcast > reddit > trends > news.
SOURCE_GAP: dict[TopicSource, float] = {
    TopicSource.GOOGLE_TRENDS: 15.0,
    TopicSource.REDDIT: 19.0,
    TopicSource.PODCAST: 22.0,
    TopicSource.NEWS_RSS: 12.0,
}


@dataclass
class StackProfile:
    """What this operation can actually produce well.

    Every field is optional; an empty profile scores neutral rather than
    guessing. Populate it from the channel config to make stack fit real."""

    niches: set[Niche] = field(default_factory=set)
    markets: set[Market] = field(default_factory=set)
    # Runtime our pipeline is tuned for, in minutes.
    duration_minutes: tuple[float, float] = (0.0, 0.0)
    # Title/format shapes we have shipped successfully (see youtube_scanner's
    # _classify_title tags: "number", "question", "listicle", "how_to", ...).
    proven_title_patterns: set[str] = field(default_factory=set)
    # Production requirements we cannot meet (e.g. "face_cam", "live_footage",
    # "interview"). Matched against raw_metrics["production_requirements"].
    unsupported_requirements: set[str] = field(default_factory=set)
    # Topics we will not make regardless of demand.
    blocked_keywords: set[str] = field(default_factory=set)

    @property
    def is_configured(self) -> bool:
        return bool(
            self.niches or self.markets or any(self.duration_minutes)
            or self.proven_title_patterns or self.unsupported_requirements
            or self.blocked_keywords
        )


class TopicScorer:
    """Score raw topics using 4 dimensions.

    kb_client is optional. If None, novelty_score defaults to 5 (neutral).
    """

    def __init__(self, kb_client=None, stack_profile: StackProfile | None = None) -> None:
        """
        kb_client: KBClient instance for novelty check.
        If None, skip novelty check (novelty_score = 5).
        stack_profile: what this operation can produce. If None, stack fit is
        neutral — an unconfigured system must not silently penalise everything.
        """
        self._kb = kb_client
        self._stack = stack_profile or StackProfile()

    async def score(self, topic: TopicRawData) -> ScoredTopic:
        """Score a single topic across all 5 dimensions."""
        trend = self._calc_trend_momentum(topic)
        gap = self._calc_gap_score(topic)
        rpm = self._calc_rpm_potential(topic.market)
        novelty = await self._calc_novelty(topic)
        stack_fit, notes = self._calc_stack_fit(topic)
        total = trend + gap + rpm + novelty + stack_fit

        return ScoredTopic(
            raw=topic,
            trend_momentum=trend,
            gap_score=gap,
            rpm_potential=rpm,
            novelty_score=novelty,
            stack_fit=stack_fit,
            total_score=min(total, 100),
            auto_approved=total >= 70,
            needs_review=50 <= total < 70,
            score_notes=notes,
        )

    async def score_batch(self, topics: list[TopicRawData]) -> list[ScoredTopic]:
        """Score multiple topics. Return sorted by total_score descending."""
        scored = [await self.score(t) for t in topics]
        return sorted(scored, key=lambda s: s.total_score, reverse=True)

    @staticmethod
    def _calc_trend_momentum(topic: TopicRawData) -> float:
        """Calculate trend momentum (0-30).

        Heuristics by source:
        - YOUTUBE_COMPETITOR: outlier_ratio → min(ratio * 3, 30)
        - GOOGLE_TRENDS: growth_pct → min(growth_pct / 10, 30)
        - REDDIT: (score / 100) → min(score_norm, 30)
        - PODCAST: listen_score → min((listen_score - 50) * 0.6, 30)
        - NEWS_RSS: mention_count → min(mention_count * 2, 30)
        """
        metrics = topic.raw_metrics or {}
        source = topic.source

        if source == TopicSource.YOUTUBE_COMPETITOR:
            ratio = metrics.get("outlier_ratio", 0)
            return min(ratio * 3, 30)
        elif source == TopicSource.GOOGLE_TRENDS:
            growth = metrics.get("growth_pct", 0)
            return min(growth / 10, 30)
        elif source == TopicSource.REDDIT:
            score = metrics.get("score", 0)
            return min(score / 100, 30)
        elif source == TopicSource.PODCAST:
            listen_score = metrics.get("listen_score", 50)
            return min((listen_score - 50) * 0.6, 30)
        elif source == TopicSource.NEWS_RSS:
            mentions = metrics.get("mention_count", 0)
            return min(mentions * 2, 30)
        else:
            return 0

    @staticmethod
    def _calc_gap_score(topic: TopicRawData) -> float:
        """Calculate gap score (0-25) — SATURATION only.

        Deliberately blind to `outlier_ratio`: that is demand, it is already
        scored in full by trend_momentum, and reading it twice let one
        measurement supply 65 of 100 points.

        For a YouTube outlier the space looks EMPTIER when:
        - the incumbent is small (a 20k-median channel breaking out means the
          big players have not taken this yet);
        - few other competitor videos already cover the topic
          (`similar_competitor_videos`);
        - the audience engaged harder than that channel's norm — people wanted
          more than the channel usually gives them.
        And FULLER when a million-view-median channel already owns it, or the
        topic is visibly covered across the competitor set.

        Missing signals contribute NOTHING in either direction. "Unknown" is not
        "empty" — that conflation is what makes an unresearched topic look like
        a discovery.
        """
        source = topic.source
        metrics = topic.raw_metrics or {}

        if source != TopicSource.YOUTUBE_COMPETITOR:
            return SOURCE_GAP.get(source, 6.0)

        score = YOUTUBE_GAP_BASE

        # 1. Incumbent scale.
        median = metrics.get("channel_median_views")
        if median:
            median = float(median)
            if median < 50_000:
                score += 8
            elif median < 250_000:
                score += 4
            elif median >= 1_000_000:
                score -= 4

        # 2. How many competitor videos already cover this topic.
        covered = metrics.get("similar_competitor_videos")
        if covered is not None:
            covered = int(covered)
            if covered == 0:
                score += 6
            elif covered <= 2:
                score += 2
            elif covered >= 5:
                score -= 8

        # 3. Engagement lift vs the channel's own norm (per-view, so not a
        #    restatement of the view outlier).
        rate = metrics.get("engagement_rate")
        channel_rate = metrics.get("channel_avg_engagement")
        if rate and channel_rate:
            lift = float(rate) / float(channel_rate)
            if lift >= 1.3:
                score += 4
            elif lift <= 0.7:
                score -= 4

        return max(0.0, min(score, GAP_MAX))

    def _calc_stack_fit(self, topic: TopicRawData) -> tuple[float, list[str]]:
        """Calculate stack fit (0-15) — can WE make this well?

        Nothing in the previous score asked this, so the pipeline happily
        auto-approved topics needing a face on camera, live footage, or a
        runtime it does not produce. Returns the score plus the reasons, because
        'rejected for fit' is only actionable if it says which constraint hit.
        """
        profile = self._stack
        metrics = topic.raw_metrics or {}
        notes: list[str] = []

        if not profile.is_configured:
            return STACK_FIT_NEUTRAL, ["stack fit: no profile configured (neutral)"]

        title_lower = (topic.title or "").lower()
        for word in profile.blocked_keywords:
            if word.lower() in title_lower:
                return 0.0, [f"stack fit 0: blocked keyword '{word}'"]

        requirements = {str(r).lower() for r in (metrics.get("production_requirements") or [])}
        unsupported = requirements & {r.lower() for r in profile.unsupported_requirements}
        if unsupported:
            return 0.0, [f"stack fit 0: needs {sorted(unsupported)} which we cannot produce"]

        score = 0.0

        # Niche (6) — the single biggest driver of whether the output is good.
        if profile.niches:
            if topic.niche in profile.niches:
                score += 6
            else:
                notes.append(f"off-niche: {topic.niche}")
        else:
            score += 3  # unknown → half credit, not full

        # Market (3).
        if profile.markets:
            if topic.market in profile.markets:
                score += 3
            else:
                notes.append(f"off-market: {topic.market}")
        else:
            score += 1.5

        # Runtime (4).
        low, high = profile.duration_minutes
        duration = metrics.get("duration_minutes")
        if low and high and duration:
            duration = float(duration)
            if low <= duration <= high:
                score += 4
            elif low * 0.6 <= duration <= high * 1.5:
                score += 2
                notes.append(f"runtime {duration:.0f}m is outside our {low:.0f}-{high:.0f}m band")
            else:
                notes.append(
                    f"runtime {duration:.0f}m is far outside our {low:.0f}-{high:.0f}m band")
        else:
            score += 2  # unknown runtime → neutral half

        # Proven format (2).
        if profile.proven_title_patterns:
            patterns = {str(p).lower() for p in (metrics.get("title_patterns") or [])}
            if patterns & {p.lower() for p in profile.proven_title_patterns}:
                score += 2
            elif patterns:
                notes.append("title format is one we have not shipped before")
            else:
                score += 1
        else:
            score += 1

        return max(0.0, min(score, STACK_FIT_MAX)), notes

    @staticmethod
    def _calc_rpm_potential(market: Market) -> float:
        """Calculate RPM potential (0-20).

        = min(MARKET_RPM[market], 20)
        """
        return min(MARKET_RPM.get(market, 7.0), 20.0)

    async def _calc_novelty(self, topic: TopicRawData) -> float:
        """Calculate novelty vs knowledge base (0-10).

        If kb_client is None → return 5 (neutral).
        Otherwise:
        - Query KB "scripts" collection with topic.title
        - If best match similarity > 0.85 → 0 (duplicate)
        - If similarity 0.7-0.85 → 3 (related)
        - If similarity < 0.7 → 10 (novel)
        """
        if self._kb is None:
            return 5

        try:
            result = await self._kb.query(
                collection="scripts",
                query_text=topic.title,
                n_results=1,
            )

            if not result or not result.get("distances"):
                return 10  # No matches = novel

            distance = result["distances"][0][0]
            similarity = 1 - distance

            if similarity > 0.85:
                return 0  # Duplicate
            elif similarity >= 0.7:
                return 3  # Related
            else:
                return 10  # Novel

        except Exception as exc:
            logger.warning(
                "Novelty check failed",
                topic=topic.title,
                error=str(exc),
            )
            return 5  # Neutral on error
